package com.tomasvold.imperialtometricconverter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.tomasvold.imperialtometricconverter.ui.theme.ImperialToMetricConverterTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ImperialToMetricConverterTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) {
                    MetricConverter()
                }
            }
        }
    }
}

@Composable
fun MetricConverter() {
    var fahrenheit by remember { mutableStateOf("") }
    var miles by remember { mutableStateOf("") }
    var lbs by remember { mutableStateOf("") }
    var liters by remember { mutableStateOf("") }
    var mpg by remember { mutableStateOf("") }
    var psi by remember { mutableStateOf("") }
    var feet by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Row for Labels (Imperial and Metric)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            //  Text("Imperial", style = MaterialTheme.typography.body1)
            //  Text("Metric", style = MaterialTheme.typography.body1)
            Text("IMPERIAL")
            Text("METRIC")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Row 1: Fahrenheit to Celsius conversion (Imperial to Metric)
        ConversionRow("Fahrenheit", "Celsius", fahrenheit, ::convertToCelsius) { fahrenheit = it }

        Spacer(modifier = Modifier.height(32.dp))

        // Row 2: Gallons to Liters conversion (Imperial to Metric)
        ConversionRow("Gallons", "Liters", liters, ::convertToLiters) { liters = it }

        Spacer(modifier = Modifier.height(32.dp))

        // Row 3: Miles to Kilometers conversion (Imperial to Metric)
        ConversionRow("Miles", "Kilometers", miles, ::convertToKilometers) { miles = it }

        Spacer(modifier = Modifier.height(32.dp))

        // Row 4: Feet to Meters conversion (Imperial to Metric)
        ConversionRow("Feet", "Meters", feet, ::convertToMeters) { feet = it }

        Spacer(modifier = Modifier.height(32.dp))

        // Row 5: LBS to Kilograms conversion (Imperial to Metric)
        ConversionRow("LBS", "Kilograms", lbs, ::convertToKilograms) { lbs = it }

        Spacer(modifier = Modifier.height(32.dp))

        // Row 6: MPG to Liters per 10 Kilometers conversion (Imperial to Metric)
        ConversionRow("MPG", "Liters/10KM", mpg, ::convertToLitersPer10Km) { mpg = it }

        Spacer(modifier = Modifier.height(32.dp))

        // Row 7: PSI to bar conversion (Imperial to Metric)
        ConversionRow("PSI", "Bar", psi, ::convertToBar) { psi = it }
    }
}

@Composable
fun ConversionRow(
    inputLabel: String,
    outputLabel: String,
    inputValue: String,
    conversionFunction: (String) -> String,
    onValueChange: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Input field (Imperial)
        OutlinedTextField(
            value = inputValue,
            onValueChange = onValueChange,
            label = { Text("Enter $inputLabel") },
            modifier = Modifier.weight(1f)
        )

        Spacer(modifier = Modifier.width(16.dp))

        // Output field (Metric)
        val outputValue = conversionFunction(inputValue)
        OutlinedTextField(
            value = outputValue,
            onValueChange = {}, // Read-only field
            label = { Text(outputLabel) },
            modifier = Modifier.weight(1f)
        )
    }
}

// Conversion functions (Example conversions)
fun convertToCelsius(fahrenheitText: String): String {
    return try {
        val fahrenheit = fahrenheitText.toFloatOrNull() ?: 0f
        val celsius = (fahrenheit - 32) * 5 / 9 // Conversion factor from F to C
        String.format("%.2f", celsius)
    } catch (e: Exception) {
        "Invalid Input"
    }
}

fun convertToKilometers(milesText: String): String {
    return try {
        val miles = milesText.toFloatOrNull() ?: 0f
        val kilometers = miles * 1.60934f // Conversion factor from miles to kilometers
        String.format("%.2f", kilometers)
    } catch (e: Exception) {
        "Invalid Input"
    }
}

fun convertToKilograms(lbsText: String): String {
    return try {
        val lbs = lbsText.toFloatOrNull() ?: 0f
        val kilograms = lbs * 0.453592f // Conversion factor from lbs to kilograms
        String.format("%.2f", kilograms)
    } catch (e: Exception) {
        "Invalid Input"
    }
}

fun convertToLiters(gallonsText: String): String {
    return try {
        val gallons = gallonsText.toFloatOrNull() ?: 0f
        val liters = gallons * 3.78541f // Conversion factor from gallons to liters
        String.format("%.2f", liters)
    } catch (e: Exception) {
        "Invalid Input"
    }
}

fun convertToLitersPer10Km(mpgText: String): String {
    return try {
        val mpg = mpgText.toFloatOrNull() ?: 0f
        val litersPer10Km = 100 / (mpg * 1.60934f * 3.78541f) // Conversion factor from mpg to liter
        String.format("%.2f", litersPer10Km)
    } catch (e: Exception) {
        "Invalid Input"
    }
}

fun convertToBar(psiText: String): String {
    return try {
        val psi = psiText.toFloatOrNull() ?: 0f
        val bar = psi * 0.0689476f // Conversion factor from psi to bar
        String.format("%.2f", bar)
    } catch (e: Exception) {
        "Invalid Input"
    }
}

fun convertToMeters(feetText: String): String {
    return try {
        val feet = feetText.toFloatOrNull() ?: 0f
        val meters = feet * 0.3048f // Conversion factor from feet to meters
        String.format("%.2f", meters)
    } catch (e: Exception) {
        "Invalid Input"
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewMetricConverter() {
    ImperialToMetricConverterTheme {
        MetricConverter()
    }
}